# This file was created automatically from build script
__xvm_version__ = '7.1.0'
__revision__ = '7996'
__branch__ = 'default'
__node__ = '33fbe18b0c685a19227abfc33c2911cd9492fa29'
