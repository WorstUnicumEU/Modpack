# This file was created automatically from build script
__xvm_version__ = '7.2.2'
__revision__ = '8026'
__branch__ = 'default'
__node__ = '2ab0963aced434f90aa6f04f1ad58d9307c77648'
